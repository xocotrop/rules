import axios from "axios";
import React, { useEffect, useState } from "react";


const RuleInput = (props) => {
    const [parameters, setParameters] = useState('');
    const [workflowName, setWorkflowName] = useState('');
    const [workflowCheck, setWorkflowCheck] = useState();
    const [workflowsObj, setWorkflowsObj] = useState();
    useEffect(() => {
        loadWorkflows();
    }, []);

    const loadWorkflows = () => {
        axios.get('https://localhost:7289/api/Rules/wokflows')
            .then(data => {
                setWorkflowsObj(data.data);
            })
            .catch(err => {
                alert(err);
                console.error(err);
            })
    };

    const handleSubmit = (e) => {
        e.preventDefault();


        const _parameters = parameters.split(',');

        saveWorkflowParams(_parameters);
    };

    const checkWorkflow = (value) => {
        setWorkflowCheck(value);

        props.outRuleInput(value);
    }

    const saveWorkflowParams = (parameters) => {
        axios.post('https://localhost:7289/api/rules/workflows/create', { parameters: parameters, workflowName: workflowName })
            .then(() => {
                alert('Salvo com sucesso');
                loadWorkflows();
            })
            .catch(err => {
                alert(err);
                console.error(err);
            })
    };

    //props.outRuleInput
    return (
        <>
            <form onSubmit={handleSubmit}>
                <div>
                    <span>Nome do fluxo:</span>
                    <input type="text" name="workflowName" onChange={(e) => setWorkflowName(e.target.value)}></input>
                    <span>Escreva os parametros de entrada</span>
                    <br />
                    <textarea onChange={(event) => setParameters(event.target.value)}>
                    </textarea>
                </div>
                <input type="submit" value={'Salvar'} />
            </form>
            <hr />
            <ul>
                {workflowsObj !== undefined && (workflowsObj.map((item, idx) => (
                    <li key={idx}>
                        <label>
                            <input onClick={(e) => checkWorkflow(e.target.value)} name="workflowname" type="radio" value={item.workflowName}></input> {item.workflowName} - {item.parameters.join(', ')}
                        </label>
                    </li>
                ))
                )}
            </ul>
        </>
    );
}

export default RuleInput;