import React, { useState, useEffect } from 'react';
import { Query, Builder, BasicConfig } from 'react-awesome-query-builder';
import axios from 'axios';
import { getApis } from '../../services/apiService';
import MaterialConfig from 'react-awesome-query-builder/lib/config/material';
import 'react-awesome-query-builder/lib/css/styles.css';

import 'react-awesome-query-builder/lib/css/compact_styles.css';
import Header from '../Header';
import RuleInput from './RuleInput';
import Rule from './Rule';

const initialConfig = BasicConfig;

// initialConfig = MaterialConfig;
// initialConfig = { ...initialConfig,
//   BasicConfig
// };

const overrideOperatorsText = [
  'equal',
  'not_equal',
  'like',
  'not_like',
  'starts_with',
  'ends_with',
  'is_empty',
  'is_not_empty'
];

const overrideOperatorsNumber = [
  'equal',
  'not_equal',
  'less',
  'less_or_equal',
  'greater',
  'greater_or_equal',
  'between',
  'not_between',
  'is_null',
  'is_not_null',
];

const templateRule = {
  blockId: null,
  rule: null
};

const RuleEditor = () => {
  const [config, setConfig] = useState(initialConfig);
  const [ruleData, setRuleData] = useState(null);
  const [apis, setApis] = useState([]);
  const [intputDataRule, setInputDataRule] = useState();
  const [workflowName, setWorklowName] = useState('');
  const [parameters, setParameters] = useState([]);
  const [workflowsObj, setWorkflowsObj] = useState();
  const [componentsRule, setComponentsRule] = useState([]);
  const [queryRules, setQueryRules] = useState([]);
  const [block, setBlocks] = useState([]);



  useEffect(() => {
    getApis()
      .then(response => {
        if (response.length > 0)
          setApis(response);
        prepareConfigFields(response);
      })
      .catch(err => {
        console.error(err)
      });
  }, []);

  const prepareConfigFields = (apis) => {
    let customFields = [];
    apis.forEach(api => {
      const schema = api.responseSchema;
      const reducedProperties = Object.entries(schema).reduce((acc, [key, value]) => {
        let mValue = '';
        if (value === 'integer' || value === 'number') {
          mValue = 'number';
        }
        else {
          mValue = value;
        }
        acc[`${api.name}.${key}`] = { label: `${api.name}.${key}`, type: mValue, apiName: api.name };
        customFields[`${api.name}.${key}`] = { label: `${api.name}.${key}`, type: mValue, apiName: api.name, operators: mValue == 'text' ? overrideOperatorsText : overrideOperatorsNumber };
        return acc;
      }, []);
      //customFields.push(reducedProperties);
    });
    const newConfig = {
      ...config,
      fields: customFields
    };
    setConfig(newConfig);
  };

  const loadApiSchema = (apiName) => {
    let api;
    apis.forEach(element => {
      if (element.name == apiName) {
        api = element;
        return;
      }
    });
    console.log(api);

    const schema = api.responseSchema;
    const reducedProperties = Object.entries(schema).reduce((acc, [key, value]) => {
      let mValue = value;
      if (value == 'integer' || value == 'number')
        mValue = 'number';
      acc[key] = { label: key, type: mValue };
      return acc;
    }, []);
    const newConfig = {
      ...config,
      fields: reducedProperties
    };

    // schema.reduce((acc, prop) => {
    //   acc[prop.name] = { label: prop.name, type: prop.type };
    //   return acc;
    // }
    setConfig(newConfig);


    // axios.get(`/api/api/schema/${apiName}`)
    //   .then(response => {
    //     const schema = response.data;
    //     const newConfig = {
    //       ...config,
    //       fields: schema.properties.reduce((acc, prop) => {
    //         acc[prop.name] = { label: prop.name, type: prop.type };
    //         return acc;
    //       }, {})
    //     };
    //     setConfig(newConfig);
    //   });
  };


  const handleSubmit = (query) => {
    if (workflowName === undefined || workflowName === '') {
      alert('Workflow não definido');
      return;
    }
    // const apiNames = [];

    // const selectedRules = [];
    // if (queryRules != undefined && queryRules.length > 0) {

    //   componentsRule.forEach(id => {
    //     const qRule = queryRules.filter(x => x.key == id);
    //     if (qRule !== undefined && qRule !== null && qRule.length > 0) {
    //       selectedRules.push(qRule[0]);
    //     }
    //   });

    // }

    //const ruleJson = convertToRulesEngineFormat(selectedRules, apiNames);
    // axios.post('https://localhost:7289/api/rules/save', { workflowName: workflowName, expression: ruleJson, apiCalls: apiNames })
    //   .then((data) => alert(data.data))
    //   .catch(err => {
    //     alert("Error!!!!");
    //     alert(err.response.data);
    //     console.error(err);
    //   });

    axios.post('https://localhost:7289/api/rules/save2', { workflowName: workflowName, rules: queryRules })
      .then((data) => alert(data.data))
      .catch(err => {
        alert("Error!!!!");
        alert(err.response.data);
        console.error(err);
      });
  };

  const convertToQueryBuilder = () => {

  };

  const prepareJsonRule = () => {
    const tpl = {
      RuleName: null,
      SuccessEvent: null,
      ErrorMessage: null,
      ErrorType: "Error",
      Expression: null
    };
  }

  const convertToRulesEngineFormat = (queries, apiNames) => {

    const rules = [];
    let count = 1;
    queries.forEach(element => {
      rules.push(
        {
          RuleName: `Rule-${count++}`,
          SuccessEvent: element.success,
          ErrorMessage: element.error,
          ErrorType: "Error",
          Expression: generateExpressionFromQuery(element.query, apiNames)
        }
      )
    });

    return {
      WorkflowName: workflowName,
      Rules: rules
      // Rules: [
      //   {
      //     RuleName: 'SampleRule',
      //     SuccessEvent: "10",
      //     ErrorMessage: "One or more adjust rules failed.",
      //     ErrorType: "Error",
      //     Expression: generateExpressionFromQuery(query, apiNames),
      //     // Actions: {
      //     //   OnSuccess:
      //     //   {
      //     //     Name: 'SuccessAction',
      //     //     Context: {
      //     //       Output: 'Success',
      //     //       Test: 1
      //     //     }
      //     //   }
      //     //   ,
      //     //   OnFailure:
      //     //   {
      //     //     Name: 'FailureAction',
      //     //     Context: {
      //     //       Output: 'Failure',
      //     //       Test: 2
      //     //     }
      //     //   }

      //     // }
      //   }
      // ]
    };
  };

  const generateExpressionFromQuery = (query, apiNames) => {
    //if (!query || !(query instanceof Map)) return '';

    const type = query.get('type');
    const properties = query.get('properties');
    const children1 = query.get('children1');

    if (type === 'group') {
      // Se for um grupo, iterar sobre todos os filhos e combinar as expressões
      const conjunction = properties.get("conjunction") || 'AND'; // Padrão para 'AND'
      const childrenExpressions = getAllChildrenExpressions(children1, apiNames);
      // Combina as expressões dos filhos usando a conjunção especificada
      return `(${childrenExpressions.join(` ${conjunction} `)})`;
    }

    if (type === 'rule') {
      // Se for uma regra, construir a expressão com base no operador e valores
      // const { field, operator, value } = properties;
      const field = properties.get('field');
      const operator = properties.get('operator');
      const value = properties.get('value');
      const valueType = properties.get('valueType').get(0);

      if (field.includes(".")) {
        const splitStr = field.split(".");
        const apiName = splitStr[0];
        if (!apiNames.includes(apiName)) {
          apiNames.push(apiName);
        }
      }

      return buildCondition(field, operator, value, valueType);
    }

    return '';
  };

  // Função para iterar sobre todos os filhos em qualquer nível
  const getAllChildrenExpressions = (children, apiNames) => {
    const expressions = [];

    // Iterar sobre as chaves e valores do Map
    //if (children instanceof Map) {
    children.forEach((child) => {
      expressions.push(generateExpressionFromQuery(child, apiNames));
    });
    //}

    return expressions;
  };

  // Função auxiliar para mapear operadores visuais para operadores de expressão
  const buildCondition = (field, operator, value, valueType) => {
    let op;
    let complexOp = false;
    let not = false;
    let buildCond = '';
    let continueBuilding = true;
    switch (operator) {
      case 'equal':
        op = ' ==';
        break;
      case 'not_equal':
        op = ' !=';
        break;
      case 'greater':
        op = ' >';
        break;
      case 'greater_or_equal':
        op = ' >=';
        break;
      case 'less':
        op = ' <';
        break;
      case 'less_or_equal':
        op = ' <=';
        break;
      case 'like':
        op = '.Contains(##val##, StringComparison.InvariantCultureIgnoreCase)';
        complexOp = true;
        break;
      case 'not_like':
        op = '.Contains(##val##, StringComparison.InvariantCultureIgnoreCase)';
        complexOp = true;
        not = true;
        break;
      case 'starts_with':
        op = '.StartsWith(##val##, StringComparison.OrdinalIgnoreCase)';
        complexOp = true;
        break;
      case 'ends_with':
        op = '.EndsWith(##val##, StringComparison.OrdinalIgnoreCase)';
        complexOp = true;
        break;
      case 'is_empty':
        op = ' string.IsNullOrWhiteSpace(##val##)';
        complexOp = true;
        break;
      case 'is_not_empty':
        op = '';
        complexOp = true;
        not = true;
        break;
      case 'is_null':
        op = '';
        complexOp = true;
        break;
      case 'is_not_null':
        op = '';
        complexOp = true;
        not = true;
        break;
      case 'between':
        op = '##val##.ValidateBetween(##start##,##end##) == true';
        complexOp = true;
        continueBuilding = false;
        buildCond = op.replace('##start##', value.get(0)).replace('##end##', value.get(1)).replace('##val##', field);
        break;
      case 'not_between':
        op = '##val##.ValidateBetween(##start##,##end##) == false';
        buildCond = op.replace('##start##', value.get(0)).replace('##end##', value.get(1)).replace('##val##', field);
        complexOp = true;
        continueBuilding = false;
        //not = true;
        break;
      default:
        op = '=='; // Por padrão, se o operador não for identificado, usar igual
    }

    if (continueBuilding) {
      let dst = value.get(0);
      if (valueType == 'text') {
        // if (!dst.includes("\"")) {
        //   alert('os campos de texto, devem ser preenchidos com aspas \'""\'');
        //   throw new Error("error");
        // }
        dst = `\"${dst}\"`;
      }

      if (complexOp) {
        op = op.replace("##val##", dst);
      } else {
        op = `${op} ${dst}`;
      }

      buildCond = `${field}${op}`;

      if (not) {
        buildCond = `!${buildCond}`;
      }
    }
    return buildCond;
  };

  const modelRuleInput = (workflowName) => {

    setWorklowName(workflowName);
    //setParameters(parameters.split(','));
    //saveWorkflowParams();
    // setInputDataRule(parameters);
    //console.log(input);
  }

  const externalRefFuncc = (rule, id) => {
    let items = [...queryRules];
    const idx = items.findIndex((x) => x.blockId == id);

    if (idx !== undefined && idx >= 0) {
      const element = items.splice(idx, idx + 1)[0];
      element.rule = rule;
      const newItems = [
        ...items,
        element
      ];

      console.log(newItems);
      setQueryRules(newItems);
      return;
    }

    const tpl = { ...templateRule };

    tpl.blockId = id;
    tpl.rule = rule;

    const newItems = [
      ...items,
      tpl
    ];
    console.log(newItems);
    setQueryRules(newItems);

  }

  const externalRefFunc = (query, success, error, key) => {

    // const element = queryRules.find((x) => x.key == key);
    const idx = queryRules.findIndex((x) => x.key == key);
    if (idx !== undefined && idx >= 0) {

      // const elements = [
      //   ...queryRules
      // ];
      const element = queryRules.splice(idx, idx + 1)[0];

      if (query !== null) {
        element.query = query;
        setQueryRules([
          ...queryRules,
          element
        ])
        return;
      }

      if (success !== null) {
        element.success = success;
        setQueryRules([
          ...queryRules,
          element
        ])
        return;
      }

      if (error !== null) {
        element.error = error;
        setQueryRules([
          ...queryRules,
          element
        ])
        return;
      }
    }
    if (query !== null) {

      setQueryRules(
        [
          ...queryRules,
          {
            key: key,
            query: query,
            error: '',
            success: ''
          }
        ]
      );
      return;
    }
    if (error !== null) {

      setQueryRules(
        [
          ...queryRules,
          {
            key: key,
            query: '',
            error: error,
            success: ''
          }
        ]
      );
      return;
    }
    if (success !== null) {

      setQueryRules(
        [
          ...queryRules,
          {
            key: key,
            query: '',
            error: '',
            success: success
          }
        ]
      );
      return;
    }

  }

  const removeItemRule = (idx) => {
    const component = componentsRule.indexOf(idx);
    if (component !== undefined && component >= 0) {
      const remove = componentsRule.splice(component, 1);
      setComponentsRule([...componentsRule]);
    }
  }

  const addBlockRule = () => {
    let count = 1;
    if (componentsRule.length > 0) {
      count = componentsRule[componentsRule.length - 1] + 1;
    }
    setComponentsRule([
      ...componentsRule,
      count
    ]);
  }

  return (
    <>
      <Header title={'Editor de regras'} />
      <RuleInput outRuleInput={modelRuleInput} ></RuleInput>
      <div>
        <h2>Editor de Regras Dinâmicas</h2>
        <div>
          WorkflowName: {workflowName || ''}
        </div>
        {/* <select onChange={(e) => loadApiSchema(e.target.value)}>
        <option value="">Selecione uma API</option>
        {apis.map(api => <option key={api.name} value={api.name}>{api.name}</option>)}
      </select> */}
        {/* {config.fields && (
          <Query
            {...config}
            value={ruleData}
            onChange={setRuleData}
            renderBuilder={(props) => (
              <div className="query-builder">
                <Builder {...props} />
              </div>
            )}
          />
        )} */}
        <div>
          {componentsRule !== undefined && (componentsRule.map((id, i) => (
            <Rule from={'external'} removeItemRule={removeItemRule} id={id} key={id} index={i} apis={apis} externalFunc={externalRefFuncc} blocks={componentsRule} />
          )))}
        </div>
        <span><button onClick={addBlockRule}>Adicionar bloco de regras</button></span>
        <button onClick={handleSubmit}>Salvar Regra</button>
      </div>
    </>
  );
};

export default RuleEditor;
