import React, { useState, useEffect } from 'react';
import { getApis, createRule } from '../../services/apiService';

const CreateRule = () => {
  const [apis, setApis] = useState([]);
  const [ruleName, setRuleName] = useState('');
  const [conditions, setConditions] = useState([]);
  const [actions, setActions] = useState([]);

  useEffect(() => {
    const fetchApis = async () => {
      const apiList = await getApis();
      setApis(apiList);
    };

    fetchApis();
  }, []);

  const handleAddCondition = () => {
    setConditions([...conditions, { apiName: '', field: '', operator: '', value: '' }]);
  };

  const handleConditionChange = (index, key, value) => {
    const updatedConditions = [...conditions];
    updatedConditions[index][key] = value;
    setConditions(updatedConditions);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const ruleData = {
      name: ruleName,
      conditions,
      actions,
    };

    try {
      await createRule(ruleData);
      alert('Regra criada com sucesso!');
    } catch (error) {
      alert('Erro ao criar regra');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>Nome da Regra:</label>
        <input type="text" value={ruleName} onChange={(e) => setRuleName(e.target.value)} required />
      </div>
      <div>
        <h3>Condições:</h3>
        {conditions.map((condition, index) => (
          <div key={index}>
            <select value={condition.apiName} onChange={(e) => handleConditionChange(index, 'apiName', e.target.value)}>
              <option value="">Selecione uma API</option>
              {apis.map((api) => (
                <option key={api.apiName} value={api.apiName}>{api.apiName}</option>
              ))}
            </select>
            <input type="text" placeholder="Campo" value={condition.field} onChange={(e) => handleConditionChange(index, 'field', e.target.value)} />
            <input type="text" placeholder="Operador" value={condition.operator} onChange={(e) => handleConditionChange(index, 'operator', e.target.value)} />
            <input type="text" placeholder="Valor" value={condition.value} onChange={(e) => handleConditionChange(index, 'value', e.target.value)} />
          </div>
        ))}
        <button type="button" onClick={handleAddCondition}>Adicionar Condição</button>
      </div>
      <div>
        <h3>Ações:</h3>
        <textarea value={actions} onChange={(e) => setActions(e.target.value)} />
      </div>
      <button type="submit">Criar Regra</button>
    </form>
  );
};

export default CreateRule;
