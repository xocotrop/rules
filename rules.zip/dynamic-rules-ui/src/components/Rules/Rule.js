import { Query, Builder, BasicConfig } from 'react-awesome-query-builder';
import 'react-awesome-query-builder/lib/css/styles.css';
import 'react-awesome-query-builder/lib/css/compact_styles.css';
import { useEffect, useState } from 'react';
import { generateExpressionFromQuery } from './Utils.js';


const overrideOperatorsText = [
    'equal',
    'not_equal',
    'like',
    'not_like',
    'starts_with',
    'ends_with',
    'is_empty',
    'is_not_empty'
];

const overrideOperatorsNumber = [
    'equal',
    'not_equal',
    'less',
    'less_or_equal',
    'greater',
    'greater_or_equal',
    'between',
    'not_between',
    'is_null',
    'is_not_null',
];




const initialConfig = BasicConfig;

const Rule = (props) => {

    const [config, setConfig] = useState(initialConfig);
    const [ruleData, setRuleData] = useState(null);
    const [successText, setSuccessText] = useState();
    const [errorText, setErrorText] = useState();
    const [success, setSuccess] = useState(null);
    const [error, setError] = useState(null);
    const [txtQuery, setTxtQuery] = useState();
    const apis = props.apis;
    const id = props.id;
    const blocks = props.blocks;
    const from = props.from;
    const [queryRules, setQueryRules] = useState({
        continueOk: null,
        continueFalse: null,
        returnOk: null,
        returnError: null,
        toA: null,
        toB: null,
        query: null,
        apiNames: null
    })


    useEffect(() => {
        prepareConfigFields();
    }, []);

    const prepareConfigFields = () => {
        let customFields = [];
        apis.forEach(api => {
            const schema = api.responseSchema;
            // console.log('schema', schema);
            // console.log('api', api);
            const reducedProperties = Object.entries(schema).reduce((acc, [key, value]) => {
                let mValue = '';
                if (value === 'integer' || value === 'number') {
                    mValue = 'number';
                }
                else {
                    mValue = value;
                }
                acc[`${api.name}.${key}`] = { label: `${api.name}.${key}`, type: mValue, apiName: api.name };
                if (mValue == 'text') {
                    customFields[`${api.name}.${key}`] = { label: `${api.name}.${key}`, type: mValue, apiName: api.name, operators: overrideOperatorsText };

                }
                else {
                    customFields[`${api.name}.${key}`] = { label: `${api.name}.${key}`, type: mValue, apiName: api.name };
                }

                return acc;
            }, []);
            //customFields.push(reducedProperties);
        });
        const newConfig = {
            ...config,
            fields: customFields
        };
        setConfig(newConfig);
    };

    const externalRefFunc = (continueOk, continueFalse, toA, toB, returnOk) => {

        if (continueOk !== null)
            setQueryRules({
                ...queryRules,
                continueOk: continueOk
            });

        if (continueFalse !== null)
            setQueryRules({
                ...queryRules,
                continueFalse: continueFalse
            });

        if (toA !== null)
            setQueryRules({
                ...queryRules,
                toA: toA
            });

        if (toB !== null)
            setQueryRules({
                ...queryRules,
                toB: toB
            });

        if (returnOk !== null)
            setQueryRules({
                ...queryRules,
                returnOk: returnOk
            });
    }

    const errorFunc = (continueFalse) => {

        const mContinue = {
            ...queryRules,
            continueFalse: continueFalse
        };

        console.log('continueFalse', mContinue);

        setQueryRules(mContinue);

        if (props.externalFunc !== undefined) {
            props.externalFunc(mContinue, id);
        }

        if (props.successFunc !== undefined) {
            props.successFunc(mContinue);
        }

        if (props.errorFunc !== undefined) {
            props.errorFunc(mContinue);
        }

        // if (continueOk !== null)
        //     setQueryRules({
        //         ...queryRules,
        //         continueOk: continueOk
        //     });

        // if (continueFalse !== null)
        //     setQueryRules({
        //         ...queryRules,
        //         continueFalse: continueFalse
        //     });

        // if (toA !== null)
        //     setQueryRules({
        //         ...queryRules,
        //         toA: toA
        //     });

        // if (toB !== null)
        //     setQueryRules({
        //         ...queryRules,
        //         toB: toB
        //     });

        // if (returnOk !== null)
        //     setQueryRules({
        //         ...queryRules,
        //         returnOk: returnOk
        //     });
    }

    const successFunc = (continueOk) => {

        const mContinue = {
            ...queryRules,
            continueOk: continueOk
        };

        console.log('continueOk', mContinue);

        setQueryRules(mContinue);


        if (props.externalFunc !== undefined) {
            props.externalFunc(mContinue, id);
        }

        if (props.successFunc !== undefined) {
            props.successFunc(mContinue);
        }

        if (props.errorFunc !== undefined) {
            props.errorFunc(mContinue);
        }

        // if (continueOk !== null)
        //     setQueryRules({
        //         ...queryRules,
        //         continueOk: continueOk
        //     });

        // if (continueFalse !== null)
        //     setQueryRules({
        //         ...queryRules,
        //         continueFalse: continueFalse
        //     });

        // if (toA !== null)
        //     setQueryRules({
        //         ...queryRules,
        //         toA: toA
        //     });

        // if (toB !== null)
        //     setQueryRules({
        //         ...queryRules,
        //         toB: toB
        //     });

        // if (returnOk !== null)
        //     setQueryRules({
        //         ...queryRules,
        //         returnOk: returnOk
        //     });
    }

    const update = (query) => {
        const apiNames = [];
        setRuleData(query);
        if (query !== undefined) {
            const compiledQuery = generateExpressionFromQuery(query, apiNames);
            const mQuery = {
                ...queryRules,
                query: compiledQuery,
                apiNames: apiNames
            };
            setQueryRules(mQuery);
            setTxtQuery(compiledQuery);
            //if (from == 'internal') {
            if (props.externalFunc !== undefined)
                // props.externalFunc(compiledQuery, null, null, props.id);
                props.externalFunc(mQuery, id);

            if (props.successFunc !== undefined) {
                props.successFunc(mQuery);
            }

            if (props.errorFunc !== undefined) {
                props.errorFunc(mQuery);
            }
            //}
            // else {
            //     if (props.externalFunc !== undefined)
            //         props.externalFunc(compiledQuery, null, null, props.id);

            //     if (props.successFunc !== undefined) {
            //         props.successFunc(mQuery);
            //     }

            //     if (props.errorFunc !== undefined) {
            //         props.errorFunc(mQuery);
            //     }
            // }
        }
    }

    const successEvent = (text) => {
        setSuccessText(text);

        const mSuccessText = {
            ...queryRules,
            returnOk: text
        }

        setQueryRules(mSuccessText);

        if (props.successFunc !== undefined) {
            props.successFunc(mSuccessText);
        }

        if (props.errorFunc !== undefined) {
            props.errorFunc(mSuccessText);
        }

        if (props.externalFunc !== undefined) {
            props.externalFunc(mSuccessText, id);
        }

    }

    const errorEvent = (text) => {
        setErrorText(text);

        const mErrorText = {
            ...queryRules,
            returnError: text
        }

        setQueryRules(mErrorText);

        if (props.successFunc !== undefined) {
            props.successFunc(mErrorText);
        }

        if (props.errorFunc !== undefined) {
            props.errorFunc(mErrorText);
        }

        if (props.externalFunc !== undefined) {
            props.externalFunc(mErrorText, id);
        }
    }

    const remove = () => {
        props.removeItemRule(props.id);
    };

    const addBlockSuccess = () => {
        setSuccess(1);
    }

    const addBlockError = () => {
        setError(1);
    }

    const removeItemSuccess = () => {
        setSuccess(null);
    }

    const removeItemError = () => {
        setError(null);
    }

    const toAFunc = (value) => {
        let mValue = value;
        if (value === undefined || value === '' || value === null)
            mValue = null;

        const updt = {
            ...queryRules,
            toA: mValue
        };

        setQueryRules(updt);

        console.log('toA', updt);

        if (props.successFunc !== undefined) {
            props.successFunc(updt);
        }

        if (props.errorFunc !== undefined) {
            props.errorFunc(updt);
        }

        if (props.externalFunc !== undefined) {
            props.externalFunc(updt, id);
        }
    }

    const changeTxtArea = (value) => {
        setTxtQuery(value);

        const mQuery = {
            ...queryRules,
            query: value
        };
        setQueryRules(mQuery);
        setTxtQuery(value);
        //if (from == 'internal') {
        if (props.externalFunc !== undefined)
            // props.externalFunc(compiledQuery, null, null, props.id);
            props.externalFunc(mQuery, id);

        if (props.successFunc !== undefined) {
            props.successFunc(mQuery);
        }

        if (props.errorFunc !== undefined) {
            props.errorFunc(mQuery);
        }

    }

    const toBFunc = (value) => {
        let mValue = value;
        if (value === undefined || value === '' || value === null)
            mValue = null;

        const updt = {
            ...queryRules,
            toB: mValue
        };

        setQueryRules(updt);

        console.log('toB', updt);

        if (props.successFunc !== undefined) {
            props.successFunc(updt);
        }

        if (props.errorFunc !== undefined) {
            props.errorFunc(updt);
        }

        if (props.externalFunc !== undefined) {
            props.externalFunc(updt, id);
        }
    }

    return (
        <>
            <div style={{
                border: "1px solid black",
                "border-radius": "10px",
                margin: "10px",
                padding: "10px",
                "box-shadow": "5px 5px 5px #0000009c"
            }}>
                <div>
                    {props.from === 'external' && (
                        <span>Bloco: {id}</span>
                    )}
                    {config.fields && (
                        <Query
                            {...config}
                            value={ruleData}
                            onChange={update}
                            renderBuilder={(props) => (
                                <div className="query-builder">
                                    <Builder {...props} />
                                </div>
                            )}
                        />
                    )}
                    <textarea value={txtQuery} onChange={(e) => changeTxtArea(e.target.value)}></textarea>
                </div>
                <div>
                    <span>Sucesso:</span>
                    <input type='text' name='success' onChange={(e) => successEvent(e.target.value)}></input>
                </div>
                <div>
                    <span>Erro:</span>
                    <input type='text' name='error' onChange={(e) => errorEvent(e.target.value)}></input>
                </div>
                <div>
                    <span>
                        Sucesso bloco: <select onChange={(e) => toAFunc(e.target.value)}>
                            <option>Selecione</option>
                            {blocks && (blocks.map((id, i) => (
                                <option value={id}>Bloco {id}</option>
                            )))}
                        </select>
                    </span>
                </div>
                <div>
                    <span>
                        Error bloco: <select onChange={(e) => toBFunc(e.target.value)}>
                            <option>Selecione</option>
                            {blocks && (blocks.map((id, i) => (
                                <option value={id}>Bloco {id}</option>
                            )))}
                        </select>
                    </span>
                </div>
                <div style={{
                    display: "flex",
                    /* flex-direction: column; */
                    "justify-content": "flex-star",
                    "flex-wrap": "wrap"
                }}>
                    <div style={{
                        "box-sizing": "border-box",
                        "max-width": "50%",
                        width: "50%"
                    }}>
                        <span>Sucesso</span>
                        <div>
                            {success && (
                                <Rule from={'internal'} removeItemRule={removeItemSuccess} successFunc={successFunc} id={id} key={id} index={1} apis={apis} blocks={props.blocks} />
                            )}
                        </div>
                        <span><button onClick={addBlockSuccess}>Adicionar condição sucesso</button></span>
                    </div>
                    <div style={{
                        "box-sizing": "border-box",
                        "max-width": "50%",
                        width: "50%"
                    }}>
                        <span>Error</span>
                        <div>
                            {error && (
                                <Rule from={'internal'} removeItemRule={removeItemError} errorFunc={errorFunc} id={id} key={id} index={1} apis={apis} blocks={props.blocks} />
                            )}
                        </div>
                        <span><button onClick={addBlockError}>Adicionar condição erro</button></span>
                    </div>
                </div>
                <span>
                    <button onClick={remove}>Remover</button>
                </span>
            </div >
        </>
    );

};

export default Rule;