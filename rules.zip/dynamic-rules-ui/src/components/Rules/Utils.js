const generateExpressionFromQuery = (query, apiNames) => {
    //if (!query || !(query instanceof Map)) return '';

    const type = query.get('type');
    const properties = query.get('properties');
    const children1 = query.get('children1');

    if (type === 'group') {
      // Se for um grupo, iterar sobre todos os filhos e combinar as expressões
      const conjunction = properties.get("conjunction") || 'AND'; // Padrão para 'AND'
      const childrenExpressions = getAllChildrenExpressions(children1, apiNames);
      // Combina as expressões dos filhos usando a conjunção especificada
      return `(${childrenExpressions.join(` ${conjunction} `)})`;
    }

    if (type === 'rule') {
      // Se for uma regra, construir a expressão com base no operador e valores
      // const { field, operator, value } = properties;
      const field = properties.get('field');
      const operator = properties.get('operator');
      const value = properties.get('value');
      const valueType = properties.get('valueType')?.get(0) || '';

      if (field && field.includes(".")) {
        const splitStr = field.split(".");
        const apiName = splitStr[0];
        if (!apiNames.includes(apiName)) {
          apiNames.push(apiName);
        }
      }

      return buildCondition(field, operator, value, valueType);
    }

    return '';
  };

  // Função para iterar sobre todos os filhos em qualquer nível
  const getAllChildrenExpressions = (children, apiNames) => {
    const expressions = [];

    // Iterar sobre as chaves e valores do Map
    //if (children instanceof Map) {
    children.forEach((child) => {
      expressions.push(generateExpressionFromQuery(child, apiNames));
    });
    //}

    return expressions;
  };

  // Função auxiliar para mapear operadores visuais para operadores de expressão
  const buildCondition = (field, operator, value, valueType) => {
    let op;
    let complexOp = false;
    let not = false;
    let buildCond = '';
    let continueBuilding = true;
    switch (operator) {
      case 'equal':
        op = ' ==';
        break;
      case 'not_equal':
        op = ' !=';
        break;
      case 'greater':
        op = ' >';
        break;
      case 'greater_or_equal':
        op = ' >=';
        break;
      case 'less':
        op = ' <';
        break;
      case 'less_or_equal':
        op = ' <=';
        break;
      case 'like':
        op = '.Contains(##val##, StringComparison.InvariantCultureIgnoreCase)';
        complexOp = true;
        break;
      case 'not_like':
        op = '.Contains(##val##, StringComparison.InvariantCultureIgnoreCase)';
        complexOp = true;
        not = true;
        break;
      case 'starts_with':
        op = '.StartsWith(##val##, StringComparison.OrdinalIgnoreCase)';
        complexOp = true;
        break;
      case 'ends_with':
        op = '.EndsWith(##val##, StringComparison.OrdinalIgnoreCase)';
        complexOp = true;
        break;
      case 'is_empty':
        op = ' string.IsNullOrWhiteSpace(##val##)';
        complexOp = true;
        break;
      case 'is_not_empty':
        op = '';
        complexOp = true;
        not = true;
        break;
      case 'is_null':
        op = '';
        complexOp = true;
        break;
      case 'is_not_null':
        op = '';
        complexOp = true;
        not = true;
        break;
      case 'between':
        op = '##val##.ValidateBetween(##start##,##end##) == true';
        complexOp = true;
        continueBuilding = false;
        buildCond = op.replace('##start##', value.get(0)).replace('##end##', value.get(1)).replace('##val##', field);
        break;
      case 'not_between':
        op = '##val##.ValidateBetween(##start##,##end##) == false';
        buildCond = op.replace('##start##', value.get(0)).replace('##end##', value.get(1)).replace('##val##', field);
        complexOp = true;
        continueBuilding = false;
        //not = true;
        break;
      default:
        op = '=='; // Por padrão, se o operador não for identificado, usar igual
    }

    if (continueBuilding) {
      let dst = value.get(0);
      if (valueType == 'text') {
        // if (!dst.includes("\"")) {
        //   alert('os campos de texto, devem ser preenchidos com aspas \'""\'');
        //   throw new Error("error");
        // }
        dst = `\"${dst}\"`;
      }

      if (complexOp) {
        op = op.replace("##val##", dst);
      } else {
        op = `${op} ${dst}`;
      }

      buildCond = `${field}${op}`;

      if (not) {
        buildCond = `!${buildCond}`;
      }
    }
    return buildCond;
  };

  export {
    generateExpressionFromQuery
  }