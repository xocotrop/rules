import React, { useEffect, useState } from 'react';
import { registerApi, getApis } from '../services/apiService';
import Header from './Header';

const RegisterApi = () => {
  const [apiData, setApiData] = useState({
    name: '',
    baseUrl: '',
    endpoint : '',
    method: 'GET',
    headers: [],
    parameters: [],
    responseSchema: {},
    requestSchema: {}
  });
  const [apiName, setApiName] = useState('');
  const [endpoint, setEndpoint] = useState('');
  const [requestSchema, setRequestSchema] = useState('');
  const [responseSchema, setResponseSchema] = useState('');
  const [apis, setApis] = useState();

  useEffect(() => {
    loadApis();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();

    // const apiData = {
    //   apiName,
    //   endpoint,
    //   requestSchema: JSON.parse(requestSchema),
    //   responseSchema: JSON.parse(responseSchema),
    // };

    // setApiData({ ...apiData,
    //   responseSchema: JSON.parse(apiData.responseSchema)
    // });

    try {
      await registerApi(apiData);
      alert('API registrada com sucesso!');
    } catch (error) {
      alert('Erro ao registrar API');
    }
  };

  const loadApis = () => {
    getApis()
    .then(data => {
      setApis(data);
    })
    .catch(error => {
      alert(error);
      console.error(error);
    })
  }

  const handleInputChange = (e) => {
    if(e.target.name == 'parameters')
    {
      let dictionary = {};
      const splitValues = e.target.value.split(',');
      splitValues.forEach(element => {
        const [key, value] = element.split("=");
        dictionary = {
          ...dictionary,
          [key] : value
        }
        // dictionary.push({
        //   [key] : value
        // });
      });
      setApiData({ ...apiData, [e.target.name]: dictionary});
      return;
    }
    if(e.target.name == "requestSchema" || e.target.name == "responseSchema")
    {
      setApiData({ ...apiData,
        [e.target.name]: JSON.parse(e.target.value)
      });
      return;
    }
    setApiData({ ...apiData, [e.target.name]: e.target.value });
  };

  return (
    <>
    <Header title={'Cadastro API'}/>
    <form onSubmit={handleSubmit}>
      <input name="name" placeholder="API Name" onChange={handleInputChange} />
      <input name="baseUrl" placeholder="Base URL" onChange={handleInputChange} />
      <input name="endpoint" placeholder="Endpoint" onChange={handleInputChange} />
      <input name="parameters" placeholder="Parameters" onChange={handleInputChange} />
      <select name="method" onChange={handleInputChange}>
        <option value="GET">GET</option>
        <option value="POST">POST</option>
        {/* Outros métodos HTTP */}
      </select>
      {/* Campos adicionais para cabeçalhos, parâmetros, etc. */}
      <textarea name="requestSchema" placeholder="JSON Schema" onChange={handleInputChange}></textarea>
      <textarea name="responseSchema" placeholder="JSON Schema" onChange={handleInputChange}></textarea>
      <button type="submit">Register API</button>
    </form>
    <hr></hr>
    <div>
      <ul>
        {apis && (apis.map((element,idx) => (
          <li>{element.name}</li>
        )))}
      </ul>
    </div>
    </>
  );
};

export default RegisterApi;
