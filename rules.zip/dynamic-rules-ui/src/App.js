import logo from './logo.svg';
import './App.css';
import RegisterApi from './components/RegisterApi';
import RuleEditor from './components/Rules/RuleEditor';
import { Routes, Route } from 'react-router-dom';

function App() {
  return (
    <>
      <Routes>
        <Route path='/' element={<RegisterApi></RegisterApi>} />
        <Route path='/api' element={<RegisterApi></RegisterApi>} />
        <Route path='/rules' element={<RuleEditor></RuleEditor>} />
      </Routes>
      {/* <div className="App">
        <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
        <RegisterApi />
        <hr></hr>
        <RuleEditor />
      </div> */}
    </>
  );
}

export default App;
