import axios from 'axios';

const API_URL = 'https://localhost:7289/api'; // URL do backend ASP.NET Core

// Registrar uma API no backend
export const registerApi = async (apiData) => {
  try {
    const response = await axios.post(`${API_URL}/api`, apiData);
    return response.data;
  } catch (error) {
    console.error('Erro ao registrar API', error);
    throw error;
  }
};

// Obter APIs cadastradas
export const getApis = async () => {
  try {
    const response = await axios.get(`${API_URL}/api`);
    return response.data;
  } catch (error) {
    console.error('Erro ao buscar APIs', error);
    throw error;
  }
};

// Criar uma regra
export const createRule = async (ruleData) => {
  try {
    const response = await axios.post(`${API_URL}/rule`, ruleData);
    return response.data;
  } catch (error) {
    console.error('Erro ao criar regra', error);
    throw error;
  }
};

// Buscar regra por ID
export const getRuleById = async (ruleId) => {
  try {
    const response = await axios.get(`${API_URL}/rule/${ruleId}`);
    return response.data;
  } catch (error) {
    console.error('Erro ao buscar regra', error);
    throw error;
  }
};
