using Microsoft.AspNetCore.Mvc;

namespace PersonalInfo.Controllers
{

    public class DataInput
    {
        public string Cpf { get; set; }
        public int Account { get; set; }
    }

    public class ResponsePersonal
    {
        public string Document { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
    }

    public class StockResponse
    {
        public string Stock { get; set; }
        public decimal Price { get; set; }
        public decimal High { get; set; }
        public decimal Low { get; set; }
    }

    public class ResponseAssets
    {
        public decimal Balance { get; set; }
        public decimal MarketShare { get; set; }
    }

    [ApiController]
    [Route("[controller]")]
    public class AssetsController : ControllerBase
    {
        public AssetsController()
        {
            
        }

        [HttpPost]
        [ProducesResponseType(typeof(ResponseAssets), 200)]
        public async Task<IActionResult> PostAsync([FromBody] DataInput input)
        {
            if ((input.Cpf != "07074655910" && input.Cpf != "08074655910") || input.Account != 7938357)
                return BadRequest("Dados inv�lidos");

            return await Task.FromResult(Ok(
                new ResponseAssets
                {
                    Balance = 198_876.87M,
                    MarketShare = 100_871.88M
                }

                ));
        }

        [HttpGet("{cpf}")]
        [ProducesResponseType(typeof(ResponseAssets), 200)]
        public async Task<IActionResult> GetAsync([FromRoute] string cpf)
        {
            return await Task.FromResult(Ok(

                new
                {
                    Balance = 198_876.87M,
                    MartketShare = 100_871.88M
                }

                ));
        }
    }


    [ApiController]
    [Route("[controller]")]
    public class PersonController : ControllerBase
    {
        public PersonController() { }

        [HttpGet("{cpf}")]
        [ProducesResponseType(typeof(ResponsePersonal), 200)]
        public async Task<IActionResult> GetAsync([FromRoute] string cpf)
        {
            return await Task.FromResult(Ok(
                new ResponsePersonal
                {
                    Document = cpf,
                    Name = "Igor Janoski",
                    Age = 34,
                    Email = "igor.sms@gmail.com",
                    Phone = "42 9 99178097"
                }
                ));
        }
    }



    [ApiController]
    [Route("[controller]")]
    public class StockController : ControllerBase
    {
        private Random random = new Random();
        private decimal GetRandom(decimal min, decimal max, int steps = 100)
        {
            if (steps <= 0) throw new ApplicationException("steps must be >= 1");
            int r = random.Next(0, steps);
            return ((steps - r) * min + r * max) / steps;
        }
        public StockController() { }

        [HttpGet("{stock}")]
        [ProducesResponseType(typeof(StockResponse), 200)]
        public async Task<IActionResult> GetAsync([FromRoute] string stock)
        {
            if(stock.ToLower() == "aapl")
            {
                return await Task.FromResult(
                    Ok(new StockResponse()
                    {
                        Stock = stock,
                        High = GetRandom(0.1M, 99),
                        Price = GetRandom(0.1M, 99),
                        Low = GetRandom(0.1M, 99)
                    }
                    ));
            }
            if(stock.ToLower() == "tsla")
            {
                return await Task.FromResult(
                   Ok(new StockResponse()
                   {
                       Stock = stock,
                       High = GetRandom(0.1M, 99),
                       Price = GetRandom(0.1M, 99),
                       Low = GetRandom(0.1M, 99)
                   }
                   ));
            }
            return await Task.FromResult(BadRequest());
        }
    }

}