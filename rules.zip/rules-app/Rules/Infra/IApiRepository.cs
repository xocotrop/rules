﻿using Rules.Services.Models;

namespace Rules.Infra
{

    public interface IApiRepository
    {
        Task<ApiData?> GetByNameAsync(string apiName);
        Task<IEnumerable<ApiData>> GetAllAsync();
        Task CreateAsync(ApiData apiDefinition);
    }


}
