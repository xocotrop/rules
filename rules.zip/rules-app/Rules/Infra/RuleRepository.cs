﻿using MongoDB.Driver;
using Rules.Infra.Models;

namespace Rules.Infra
{


    public class RuleRepository : IRuleRepository
    {
        private readonly IMongoCollection<RuleModel> _collection;
        private readonly IMongoCollection<ParamWorkflowModel> _workflows;
        private readonly IMongoCollection<RuleModel2> _collectionRule2;

        public RuleRepository(IMongoDatabase database)
        {
            _workflows = database.GetCollection<ParamWorkflowModel>("Workflows");
            _collection = database.GetCollection<RuleModel>("Rules");
            _collectionRule2 = database.GetCollection<RuleModel2>("Rules2");
        }

        public async Task CreateOrUpdate(ParamWorkflowModel paramWorkflowModel)
        {
            await _workflows.ReplaceOneAsync(x => x.WorkflowName == paramWorkflowModel.WorkflowName, paramWorkflowModel, new ReplaceOptions() { IsUpsert = true });
        }

        public async Task<IEnumerable<ParamWorkflowModel>> GetAllParamsWorkFlowAsync()
        {
            var paramsworksFlows = await _workflows.Find(_ => true).ToListAsync();

            return paramsworksFlows;
        }

        public async Task<ParamWorkflowModel?> GetParamWorkFlowAsync(string workflowName)
        {
            var workflow = await _workflows.Find(x => x.WorkflowName == workflowName).FirstOrDefaultAsync();

            return workflow;
        }

        public async Task<RuleModel> GetByIdAsync(string ruleId)
        {
            return await _collection.Find(rule => rule.Id == ruleId).FirstOrDefaultAsync();
        }

        public async Task<RuleModel> getByWorkFlowNameAsync(string workflowName)
        {
            return await _collection.Find(rule => rule.WorkflowName == workflowName).FirstOrDefaultAsync();
        }

        public async Task<RuleModel2> getByWorkFlowName2Async(string workflowName)
        {
            return await _collectionRule2.Find(rule => rule.WorkflowName == workflowName).FirstOrDefaultAsync();
        }

        public async Task<IEnumerable<RuleModel>> GetAllAsync()
        {
            return await _collection.Find(_ => true).ToListAsync();
        }

        public async Task CreateAsync(RuleModel rule)
        {
            await _collection.ReplaceOneAsync(x => x.WorkflowName == rule.WorkflowName, rule, new ReplaceOptions() { IsUpsert = true });
        }

        public async Task CreateAsync(RuleModel2 rule)
        {
            await _collectionRule2.ReplaceOneAsync(x => x.WorkflowName == rule.WorkflowName, rule, new ReplaceOptions() { IsUpsert = true });
        }
    }


}
