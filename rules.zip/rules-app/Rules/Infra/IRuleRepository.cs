﻿using Rules.Infra.Models;

namespace Rules.Infra
{
    public interface IRuleRepository
    {
        Task<RuleModel> GetByIdAsync(string ruleId);
        Task<IEnumerable<RuleModel>> GetAllAsync();
        Task CreateAsync(RuleModel rule);
        Task CreateOrUpdate(ParamWorkflowModel paramWorkflowModel);
        Task<ParamWorkflowModel?> GetParamWorkFlowAsync(string workflowName);
        Task<IEnumerable<ParamWorkflowModel>> GetAllParamsWorkFlowAsync();
        Task<RuleModel> getByWorkFlowNameAsync(string workflowName);
        Task CreateAsync(RuleModel2 rule);
        Task<RuleModel2> getByWorkFlowName2Async(string workflowName);
    }


}
