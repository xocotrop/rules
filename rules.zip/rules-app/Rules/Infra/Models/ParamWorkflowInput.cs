﻿namespace Rules.Infra.Models
{
    public class ParamWorkflowInput
    {
        public ParamWorkflowInput()
        {

        }
        public string WorkflowName { get; set; } = default!;
        public List<string> Parameters { get; set; } = new List<string>();
    }


}
