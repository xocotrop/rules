﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;
using RulesEngine.Models;

namespace Rules.Infra.Models
{

    public class RuleModel
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string? Id { get; set; } = default!;
        public string WorkflowName { get; set; } = default!;
        public Workflow Expression { get; set; } = default!;
        public List<string>? ApiCalls { get; set; }
    }

    public class RuleModel2
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string? Id { get; set; } = default!;
        public string WorkflowName { get; set; } = default!;
        public IEnumerable<RuleModel3> Rules { get; set; } = default!;
    }

    public class RuleModel3
    {
        public int? BlockId { get;  set; }
        public RuleModel4? Rule { get;  set; }
    }

    public class RuleModel4
    {
        public RuleModel4? ContinueOk { get; set; }
        public RuleModel4? ContinueFalse { get; set; }
        public string? ReturnOk { get; set; }
        public string? ReturnError { get; set; }
        public int? ToA { get; set; }
        public int? ToB { get; set; }
        public string Query { get; set; } = default!;
        public IEnumerable<string>? ApiNames { get; set; }
    }


}
