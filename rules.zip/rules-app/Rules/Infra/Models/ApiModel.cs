﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;

namespace Rules.Infra.Models
{
    public class ApiModel
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; } = default!;
        public string Name { get; set; } = default!;
        public string BaseUrl { get; set; } = default!;
        public string Method { get; set; } = default!;
        public string Endpoint { get; set; } = default!;
        public List<Header> Headers { get; set; } = default!;
        public Dictionary<string, string> Parameters { get; set; } = default!;
        public string RequestSchema { get; set; } = default!;
        public string ResponseSchema { get; set; } = default!;
    }

    public class Header
    {
        public string Key { get; set; }
        public string Value { get; set; }
    }

}
