﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;

namespace Rules.Infra.Models
{
    public class ParamWorkflowModel
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string? Id { get; set; }
        public string WorkflowName { get; set; } = default!;
        public List<string> Parameters { get; set; } = new List<string>();
    }


}
