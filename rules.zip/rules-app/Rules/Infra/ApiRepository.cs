﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using MongoDB.Driver;
using Rules.Infra.Models;
using Rules.Services.Models;
using System.Text.Json;

namespace Rules.Infra
{
    public class ApiRepository : IApiRepository
    {
        private readonly IMongoCollection<ApiModel> _collection;

        public ApiRepository(IMongoDatabase database)
        {
            _collection = database.GetCollection<ApiModel>("Apis");
        }

        public async Task<ApiData?> GetByNameAsync(string apiName)
        {
            var api = await _collection.Find(api => api.Name == apiName).FirstOrDefaultAsync();
            if (api == null)
            {
                return null;
            }

            return new ApiData
            {
                ResponseSchema = JsonSerializer.Deserialize<Dictionary<string, string>>(api.ResponseSchema),
                RequestSchema = JsonSerializer.Deserialize<Dictionary<string, string>>(api.RequestSchema),
                BaseUrl = api.BaseUrl,
                Endpoint = api.Endpoint,
                Headers = api.Headers,
                Method = api.Method,
                Name = api.Name,
                Parameters = api.Parameters
            };
        }

        public async Task<IEnumerable<ApiData>> GetAllAsync()
        {
            var list = await _collection.Find(_ => true).ToListAsync();

            return list.Select(x => new ApiData
            {
                ResponseSchema = JsonSerializer.Deserialize<Dictionary<string, string>>(x.ResponseSchema),
                RequestSchema = JsonSerializer.Deserialize<Dictionary<string, string>>(x.RequestSchema),
                BaseUrl = x.BaseUrl,
                Endpoint = x.Endpoint,
                Headers = x.Headers,
                Method = x.Method,
                Name = x.Name,
                Parameters = x.Parameters
            });
        }

        public async Task CreateAsync(ApiData apiDefinition)
        {
            var a = JsonSerializer.Serialize(apiDefinition.RequestSchema);
            var bsonA = BsonSerializer.Deserialize<BsonDocument>(a);

            var b = JsonSerializer.Serialize(apiDefinition.ResponseSchema);
            var bsonB = BsonSerializer.Deserialize<BsonDocument>(b);

            var toModel = new ApiModel
            {
                Id = ObjectId.GenerateNewId().ToString(),
                BaseUrl = apiDefinition.BaseUrl,
                Endpoint = apiDefinition.Endpoint,
                Headers = apiDefinition.Headers,
                Method = apiDefinition.Method,
                Name = apiDefinition.Name,
                Parameters = apiDefinition.Parameters,
                RequestSchema = a,
                ResponseSchema = b
            };

            await _collection.ReplaceOneAsync(x => x.Name == apiDefinition.Name, toModel, new ReplaceOptions() { IsUpsert = true });
        }
    }


}
