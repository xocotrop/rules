﻿using Rules.Utils;

namespace Rules.Utils
{
    public static class ExpressionUtils
    {
        public static bool ValidateBetween(this int validate, int from, int to)
        {
            return Enumerable.Range(from, to - from + 1).Contains(validate);
        }

        public static bool ValidateBetween(this long validate, int from, int to)
        {
            return Enumerable.Range(from, to - from + 1).Contains((int)validate);
        }

        public static bool ValidateBetween(this decimal validate, decimal minValue, decimal maxValue)
        {
            return minValue.CompareTo(validate) == -1 && validate.CompareTo(maxValue) == -1;
        }

        public static bool ValidateBetween(this decimal validate, int minValue, int maxValue)
        {
            return ((decimal)minValue).CompareTo(validate) == -1 && validate.CompareTo(maxValue) == -1;
        }

    }
}
