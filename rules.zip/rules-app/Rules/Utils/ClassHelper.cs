﻿using System.Reflection.Emit;
using System.Reflection;
using System.Text.Json;

namespace Rules.Utils
{
    public class ClassHelper
    {

        public static void PopulateDynamicClass(object dynamicInstance, Dictionary<string, object> data)
        {
            Type dynamicType = dynamicInstance.GetType();

            foreach (var kvp in data)
            {
                // Encontra a propriedade correspondente na classe dinâmica
                PropertyInfo prop = dynamicType.GetProperty(kvp.Key);

                if (prop != null)
                {
                    if (kvp.Value is JsonElement jsonElement)
                    {
                        object value = ConvertJsonElement(jsonElement, prop.PropertyType);
                        prop.SetValue(dynamicInstance, value);
                    }
                    else
                    {
                        // Se não for JsonElement, usa Convert.ChangeType como antes
                        object value = Convert.ChangeType(kvp.Value, prop.PropertyType);
                        prop.SetValue(dynamicInstance, value);
                    }
                }
            }
        }

        public static object ConvertJsonElement(JsonElement jsonElement, Type targetType)
        {
            // Verifica o tipo de destino e converte o JsonElement apropriadamente
            if (targetType == typeof(string))
            {
                return jsonElement.GetString()!;
            }
            if (targetType == typeof(int))
            {
                return jsonElement.GetInt32();
            }
            if (targetType == typeof(bool))
            {
                return jsonElement.GetBoolean();
            }
            if (targetType == typeof(double))
            {
                return jsonElement.GetDouble();
            }
            if (targetType == typeof(decimal))
            {
                return jsonElement.GetDecimal();
            }

            // Adicione outras conversões conforme necessário

            // Valor padrão se o tipo não for suportado
            return jsonElement.ToString();
        }

        public static Type GetTypeFromSchema(string schemaType)
        {
            return schemaType.ToLower() switch
            {
                "text" => typeof(string),
                "number" => typeof(decimal),
                "integer" => typeof(int),
                "boolean" => typeof(bool),
                _ => typeof(object) // Tipo padrão se não for conhecido
            };
        }
        public static Type CreateDynamicClass(Dictionary<string, string> schema)
        {
            // Definindo um assembly e módulo dinâmico
            AssemblyName assemblyName = new AssemblyName("DynamicClasses");
            AssemblyBuilder assemblyBuilder = AssemblyBuilder.DefineDynamicAssembly(assemblyName, AssemblyBuilderAccess.Run);
            ModuleBuilder moduleBuilder = assemblyBuilder.DefineDynamicModule("MainModule");

            // Definindo a classe
            TypeBuilder typeBuilder = moduleBuilder.DefineType("DynamicClass", TypeAttributes.Public);

            // Adicionando propriedades à classe com base no schema
            foreach (var kvp in schema)
            {
                string propertyName = kvp.Key;
                Type propertyType = GetTypeFromSchema(kvp.Value);

                // Definindo a propriedade
                FieldBuilder fieldBuilder = typeBuilder.DefineField("_" + propertyName, propertyType, FieldAttributes.Private);
                PropertyBuilder propertyBuilder = typeBuilder.DefineProperty(propertyName, PropertyAttributes.HasDefault, propertyType, null);

                // Criando os métodos 'get' e 'set'
                MethodBuilder getMethodBuilder = typeBuilder.DefineMethod("get_" + propertyName, MethodAttributes.Public | MethodAttributes.SpecialName | MethodAttributes.HideBySig, propertyType, Type.EmptyTypes);
                ILGenerator getIL = getMethodBuilder.GetILGenerator();
                getIL.Emit(OpCodes.Ldarg_0);
                getIL.Emit(OpCodes.Ldfld, fieldBuilder);
                getIL.Emit(OpCodes.Ret);

                MethodBuilder setMethodBuilder = typeBuilder.DefineMethod("set_" + propertyName, MethodAttributes.Public | MethodAttributes.SpecialName | MethodAttributes.HideBySig, null, new Type[] { propertyType });
                ILGenerator setIL = setMethodBuilder.GetILGenerator();
                setIL.Emit(OpCodes.Ldarg_0);
                setIL.Emit(OpCodes.Ldarg_1);
                setIL.Emit(OpCodes.Stfld, fieldBuilder);
                setIL.Emit(OpCodes.Ret);

                // Atribuindo os métodos 'get' e 'set' à propriedade
                propertyBuilder.SetGetMethod(getMethodBuilder);
                propertyBuilder.SetSetMethod(setMethodBuilder);
            }

            // Criando a classe
            Type dynamicType = typeBuilder.CreateType();
            return dynamicType;
        }
    }
}
