﻿namespace Rules.Models
{
    public class ApiDefinition
    {
        public string ApiName { get; set; }
        public string Endpoint { get; set; }
        //public Dictionary<string, string> Parameters { get; set; }
        public Dictionary<string, string> RequestSchema { get; set; }
        public Dictionary<string, string> ResponseSchema { get; set; }
    }


}
