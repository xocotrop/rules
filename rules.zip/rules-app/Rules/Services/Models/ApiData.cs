﻿using Rules.Infra.Models;

namespace Rules.Services.Models
{
    public class ApiData
    {
        public string Name { get; set; } = default!;
        public string BaseUrl { get; set; } = default!;
        public string Method { get; set; } = default!;
        public string Endpoint { get; set; } = default!;
        public List<Header> Headers { get; set; } = default!;
        public Dictionary<string, string> Parameters { get; set; } = default!;
        public Dictionary<string, string>? RequestSchema { get; set; } = default!;
        public Dictionary<string, string>? ResponseSchema { get; set; } = default!;

        public void BindValuesParameters(Dictionary<string, object>? dictionaryObject)
        {
            if (dictionaryObject == null)
                return;

            if (Parameters != null && Parameters.Any())
            {
                foreach (var item in Parameters)
                {
                    if (dictionaryObject.ContainsKey(item.Value))
                    {
                        Parameters[item.Key] = dictionaryObject[item.Value].ToString()!;// expando.GetType().GetProperty(item.Value)?.GetValue(expando, null) as string ?? string.Empty;

                        if (RequestSchema != null && RequestSchema.ContainsKey(item.Key))
                        {
                            RequestSchema[item.Key] = dictionaryObject[item.Value].ToString()!; //expando.GetType().GetProperty(item.Value)?.GetValue(expando, null) as string ?? string.Empty;
                        }
                    }

                }
            }
        }

    }



}
