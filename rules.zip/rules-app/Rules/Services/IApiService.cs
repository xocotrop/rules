﻿using Rules.Services.Models;

namespace Rules.Services
{
    public interface IApiService
    {
        Task<object> CallApiAsync(ApiData apiData);
    }
}