﻿using Rules.Infra;
using Rules.Services.Models;
using Rules.Utils;
using System.Data;
using System.Text;
using System.Text.Json;

namespace Rules.Services
{
    public class ApiService : IApiService
    {
        private readonly IApiRepository _apiRepository;

        public ApiService(IApiRepository apiRepository)
        {
            _apiRepository = apiRepository;
        }

        public async Task<object> CallApiAsync(ApiData apiData)
        {

            using var client = new HttpClient();

            if (apiData.Parameters != null && apiData.Parameters.Any())
            {
                foreach (var parameter in apiData.Parameters)
                {
                    apiData.Endpoint = apiData.Endpoint.Replace(string.Concat("{", parameter.Key, "}"), parameter.Value);
                }
            }

            client.BaseAddress = new Uri(apiData.BaseUrl);

            var requestMessage = new HttpRequestMessage(new HttpMethod(apiData.Method), apiData.Endpoint);
            // Adicionar headers e parâmetros dinâmicos
            requestMessage.Content = new StringContent(JsonSerializer.Serialize(apiData.RequestSchema), Encoding.UTF8, "application/json");

            var response = await client.SendAsync(requestMessage);

            if (!response.IsSuccessStatusCode)
                return null;



            Type dynamicClass = ClassHelper.CreateDynamicClass(apiData.ResponseSchema);

            object dynamicInstance = Activator.CreateInstance(dynamicClass);

            var result = JsonSerializer.Deserialize<Dictionary<string, object>>(await response.Content.ReadAsStringAsync())!;

            ClassHelper.PopulateDynamicClass(dynamicInstance, result);

            return dynamicInstance;
        }



        
    }


}
