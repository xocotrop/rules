﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Rules.Infra;
using Rules.Services;
using Rules.Services.Models;
using RulesEngine.Extensions;
using RulesEngine.Models;
using System.Text.Json;

namespace Rules.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ApiController : ControllerBase
    {
        private readonly IApiService _apiService;
        private readonly IApiRepository _apiRepository;

        public ApiController(IApiService apiService, IApiRepository apiRepository)
        {
            _apiService = apiService;
            _apiRepository = apiRepository;
        }

        [HttpPost()]
        public async Task<IActionResult> RegisterApi([FromBody] ApiData apiData)
        {
            await _apiRepository.CreateAsync(apiData);
            return Ok();
        }

        [HttpGet]
        public async Task<IActionResult> GetApis()
        {
            var apis = await _apiRepository.GetAllAsync();
            return Ok(apis);
        }

        [HttpGet("test")]
        public async Task<IActionResult> Test()
        {
            var rule = @"[
                          {
                            ""WorkflowName"": ""Discount"",
                            ""Rules"": [
                              {
                                ""RuleName"": ""GiveDiscount10"",
                                ""SuccessEvent"": ""10"",
                                ""ErrorMessage"": ""One or more adjust rules failed."",
                                ""ErrorType"": ""Error"",
                                ""Expression"": ""input1.country == \""india\"" AND input1.loyaltyFactor <= 2 AND input1.totalPurchasesToDate >= 5000""
                              },
                              {
                                ""RuleName"": ""GiveDiscount20"",
                                ""SuccessEvent"": ""20"",
                                ""ErrorMessage"": ""One or more adjust rules failed."",
                                ""ErrorType"": ""Error"",
                                ""Expression"": ""input1.country == \""india\"" AND input1.loyaltyFactor >= 3 AND input1.totalPurchasesToDate >= 10000""
                              }
                            ]
                          }
                        ]";

            var input1 = new { Country = "india", loyaltyFactor = 2, totalPurchasesToDate = 5000 };

            var inputs = new dynamic[]
            {
                input1
            };

            var lW = JsonSerializer.Deserialize<List<Workflow>>(rule)!;


            var re = new RulesEngine.RulesEngine(lW.ToArray());

            var result = await re.ExecuteAllRulesAsync("Discount", inputs);
            Console.WriteLine(result);
            string t = string.Empty;
            result.OnSuccess((x) =>
            {
                t = x;
            });

            result.OnFail(() =>
            {

            });

            return await Task.FromResult(Ok(t));
        }
        //[HttpPost("call/{apiName}")]
        //public async Task<IActionResult> CallApi(string apiName, [FromBody] object parameters)
        //{
        //    var result = await _apiService.CallApiAsync(apiName, parameters);
        //    return Ok(result);
        //}
    }
}
