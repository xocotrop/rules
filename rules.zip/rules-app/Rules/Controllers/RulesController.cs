﻿using Microsoft.AspNetCore.Mvc;
using MongoDB.Bson;
using Rules.Core;
using Rules.Infra;
using Rules.Infra.Models;
using Rules.Services;
using Rules.Utils;
using RulesEngine.Extensions;
using RulesEngine.Models;
using System.Collections.Concurrent;
using System.Dynamic;
using System.Text.Json;

namespace Rules.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RulesController : ControllerBase
    {
        private readonly RulesEngine.RulesEngine _rulesEngine;

        private readonly IRuleRepository _ruleRepository;
        private readonly IApiService _apiService;
        private readonly IApiRepository _apiRepository;
        private readonly IRuleProcessor _ruleProcessor;

        public RulesController(IRuleRepository ruleRepository, IApiService apiService, IApiRepository apiRepository, IRuleProcessor ruleProcessor)
        {
            _rulesEngine = new RulesEngine.RulesEngine();
            _ruleRepository = ruleRepository;
            _apiService = apiService;
            _apiRepository = apiRepository;
            _ruleProcessor = ruleProcessor;
        }

        [HttpPost("workflows/create")]
        public async Task<IActionResult> CreateWorkflowAsync([FromBody] ParamWorkflowInput input)
        {
            var mapToModel = new ParamWorkflowModel
            {
                Id = ObjectId.GenerateNewId().ToString(),
                Parameters = input.Parameters,
                WorkflowName = input.WorkflowName
            };

            await _ruleRepository.CreateOrUpdate(mapToModel);

            return await Task.FromResult(Ok(input));
        }

        [HttpGet("wokflows")]
        public async Task<IActionResult> LoadWorkflowsAsync()
        {
            var paramsWorkflowsAsync = await _ruleRepository.GetAllParamsWorkFlowAsync();

            return Ok(paramsWorkflowsAsync);
        }

        [HttpPost("execution2/{workflow}")]
        public async Task<IActionResult> Execute2Async([FromRoute] string workflow, [FromBody] Object objInput)
        {


            var dictionaryObject = JsonSerializer.Deserialize<Dictionary<string, object>>(objInput!.ToString());

            var (success, message) = await _ruleProcessor.ProccessEvent2(workflow, dictionaryObject, null, null);

            if (success)
                return await Task.FromResult(Ok(message));

            return await Task.FromResult(BadRequest(message));
        }

        [HttpPost("execution/{workflow}")]
        public async Task<IActionResult> ExecuteAsync([FromRoute] string workflow, [FromBody] Object objInput)
        {



            //var mWorkflow = await _ruleRepository.GetParamWorkFlowAsync(workflow);
            //var rules = await _ruleRepository.getByWorkFlowNameAsync(workflow);

            var dictionaryObject = JsonSerializer.Deserialize<Dictionary<string, object>>(objInput!.ToString());

            var (success, message) = await _ruleProcessor.ProccessEvent(workflow, dictionaryObject);

            //var parameters = new List<RuleParameter>();
            //List<(string,Task<object>)> tasks = new List<(string,Task<object>)>();
            //foreach (var apiname in rules.ApiCalls)
            //{
            //    var api = await _apiRepository.GetByNameAsync(apiname);
            //    api?.BindValuesParameters(dictionaryObject);
            //    var resultapi = _apiService.CallApiAsync(api);
            //    tasks.Add((apiname, resultapi));
            //}

            //Task.WaitAll(tasks.Select(x => x.Item2).ToArray());

            //foreach (var (apiname, task) in tasks)
            //{
            //    parameters.Add(new RuleParameter(apiname, (await task) ?? throw new Exception($"Erro ao consultar a api: {apiname}")));
            //}


            //var reSetting = new ReSettings() { CustomTypes = new Type[] { typeof(ExpressionUtils) } };

            //var re = new RulesEngine.RulesEngine(new Workflow[] { rules.Expression }, reSetting);

            //var result = await re.ExecuteAllRulesAsync(rules.Expression.WorkflowName, parameters.ToArray());
            //Console.WriteLine(result);
            //string? success = null;
            //string error = string.Empty;
            //result.OnSuccess((x) =>
            //{
            //    success = x;
            //});


            //result.OnFail(() =>
            //{
            //    foreach (var a in result)
            //    {
            //        error += a.Rule.ErrorMessage + "\r\n";
            //    }
            //});

            if (success)
                return await Task.FromResult(Ok(message));

            return await Task.FromResult(BadRequest(message));
        }

        [HttpPost("save")]
        public async Task<IActionResult> CreateRule([FromBody] RuleModel workflow)
        {
            workflow.Id = ObjectId.GenerateNewId().ToString();
            await _ruleRepository.CreateAsync(workflow);

            var workflowRule = await _ruleRepository.GetParamWorkFlowAsync(workflow.Expression.WorkflowName);

            if (workflowRule == null)
            {
                return BadRequest("Workflow não encontrado");
            }


            //Workflow workflow = null;
            ////workflow.WorkflowName
            //foreach (var item in workflow.Rules)
            //{
            //    item.RuleName;
            //    item.Actions.OnSuccess.
            //}

            //await _ruleRepository.CreateAsync(rule);

            var person = new { name = "Igor Janoski dos Santos", document = "07074655910", age = (int)25 };
            var assets = new { balance = 500, marketShare = 20 };

            var dicReplace = new Dictionary<string, string>();
            int seq = 1;

            var parameters = new List<RuleParameter>();
            //{
            //    new RuleParameter("person", person),
            //    new RuleParameter("assets", assets)
            //};


            foreach (var api in workflow.ApiCalls)
            {

                //var mapi = await _apiRepository.GetByNameAsync(api);

                //var result = await _apiService.CallApiAsync(api)

                object r;
                if (api == "person")
                {
                    r = person;
                    parameters.Add(new RuleParameter(api, r));
                }

                if (api == "assets")
                {
                    r = assets;
                    parameters.Add(new RuleParameter(api, r));
                }
                //dicReplace.Add(api, "input" + seq++);
            }


            var inputs = new dynamic[]
            {
                person, assets
            };



            //Enumerable.Range(1,100).Contains(5)

            //foreach (var rule in workflow.Expression.Rules)
            //{
            //    foreach (var item in dicReplace)
            //    {
            //        rule.Expression = rule.Expression.Replace(item.Key, item.Value);

            //    }
            //}

            var reSetting = new ReSettings() { CustomTypes = new Type[] { typeof(ExpressionUtils) } };

            var re = new RulesEngine.RulesEngine(new Workflow[] { workflow.Expression }, reSetting);

            var result = await re.ExecuteAllRulesAsync(workflow.Expression.WorkflowName, parameters.ToArray());
            Console.WriteLine(result);
            string? success = null;
            string error = string.Empty;
            result.OnSuccess((x) =>
            {
                success = x;
            });


            result.OnFail(() =>
            {
                foreach (var a in result)
                {
                    error += a.Rule.ErrorMessage + "\r\n";
                }
            });

            if (string.IsNullOrWhiteSpace(error))
                return await Task.FromResult(Ok(success));

            return await Task.FromResult(BadRequest(error));

        }

        [HttpPost("save2")]
        public async Task<IActionResult> CreateRule2([FromBody] RuleModel2 workflow)
        {
            workflow.Id = ObjectId.GenerateNewId().ToString();
            await _ruleRepository.CreateAsync(workflow);

            
                return await Task.FromResult(Ok("ok"));

        }
        //[HttpPost("evaluate")]
        //public async Task<IActionResult> EvaluateRule([FromBody] RuleModel ruleModel, [FromBody] object input)
        //{
        //    var workflows = System.Text.Json.JsonSerializer.Deserialize<List<Workflow>>(ruleModel.Expression);
        //    var engine = new RulesEngine.RulesEngine(workflows.ToArray());

        //    var inputs = new RuleParameter[] { new RuleParameter("input", input) };
        //    var result = await engine.ExecuteAllRulesAsync(ruleModel.WorkflowName, inputs);

        //    return Ok(result);
        //}
    }
}
