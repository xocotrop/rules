﻿//namespace Rules
//{
//    public class RuleContext
//    {
//        public EventData EventData { get; set; }
//        public Dictionary<string, Dictionary<string, object>> ApiResults { get; set; } = new Dictionary<string, Dictionary<string, object>>();
//    }


//}
