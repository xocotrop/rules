﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Rules.Infra;
using Rules.Infra.Models;
using Rules.Services;
using Rules.Utils;
using RulesEngine.Extensions;
using RulesEngine.Models;
using System.Data;

namespace Rules.Core
{
    public class RuleProcessor : IRuleProcessor
    {
        private readonly IApiRepository _apiRepository;
        private readonly IRuleRepository _ruleRepository;
        private readonly RulesEngine.RulesEngine _rulesEngine;
        private readonly IApiService _apiService;
        private readonly IMemoryCache _cache;
        private static readonly ReSettings _reSetting = new ReSettings() { CustomTypes = new Type[] { typeof(ExpressionUtils) } };

        public RuleProcessor(IApiRepository apiRepository, IRuleRepository ruleRepository, IApiService apiService, IMemoryCache cache)
        {
            _apiRepository = apiRepository;
            _ruleRepository = ruleRepository;
            _rulesEngine = new RulesEngine.RulesEngine(new List<Workflow>().ToArray(), null);
            _apiService = apiService;
            _cache = cache;
        }

        public async Task<(bool success, string message)> ProccessEvent2(string workflow, Dictionary<string, object> dataObjectInut, RuleModel4? ruleModel, int? targetRule = null)
        {

            var mWorkflow = await _cache.GetOrCreateAsync($"W2_{workflow}", cacheEntry =>
            {
                cacheEntry.AbsoluteExpiration = DateTime.Now.AddSeconds(2);
                return _ruleRepository.GetParamWorkFlowAsync(workflow);
            });

            //as ParamWorkflowModel ??  await _ruleRepository.GetParamWorkFlowAsync(workflow);

            var rules = await _cache.GetOrCreateAsync($"R2_{workflow}", async cacheEntry =>
            {
                cacheEntry.AbsoluteExpiration = DateTime.Now.AddSeconds(2);
                var rules = await _ruleRepository.getByWorkFlowName2Async(workflow);
                rules.Rules = rules.Rules.OrderBy(x => x.BlockId);
                return rules;
            });

            if (targetRule != null)
            {
                ruleModel = rules.Rules.FirstOrDefault(x => x.BlockId == targetRule)?.Rule;
            }

            if (ruleModel != null)
            {
                var workfloww = new Workflow()
                {
                    WorkflowName = rules.WorkflowName,
                    Rules = new List<RulesEngine.Models.Rule>() { new RulesEngine.Models.Rule() {
                        RuleName = $"Rule-{ruleModel.GetHashCode()}"
                        , SuccessEvent = ruleModel.ReturnOk
                        , ErrorMessage = ruleModel.ReturnError
                        , Expression = ruleModel.Query} }
                };

                var re2 = new RulesEngine.RulesEngine(new Workflow[] { workfloww }, _reSetting);

                List<(string, Task<object>)> tasks2 = new();
                foreach (var apiname in ruleModel.ApiNames)
                {

                    var api = await _cache.GetOrCreateAsync($"A2_{apiname}", cacheEntry =>
                    {
                        cacheEntry.AbsoluteExpiration = DateTime.Now.AddSeconds(2);
                        return _apiRepository.GetByNameAsync(apiname);
                    });

                    //var api =  await _apiRepository.GetByNameAsync(apiname);
                    api?.BindValuesParameters(dataObjectInut);
                    var resultapi = _apiService.CallApiAsync(api!);
                    tasks2.Add((apiname, resultapi));
                }


                Task.WaitAll(tasks2.Select(x => x.Item2).ToArray());
                var parameters2 = new List<RuleParameter>();

                foreach (var (apiname, task) in tasks2)
                    parameters2.Add(new RuleParameter(apiname, await task ?? throw new Exception($"Erro ao consultar a api: {apiname}")));

                var result2 = await re2.ExecuteAllRulesAsync(rules.WorkflowName, parameters2.ToArray());

                if (result2[0].IsSuccess)
                {
                    if (!string.IsNullOrWhiteSpace(ruleModel.ReturnOk))
                    {
                        return (true, ruleModel.ReturnOk);
                    }

                    if (ruleModel.ContinueOk != null)
                    {
                        return await ProccessEvent2(workflow, dataObjectInut, ruleModel.ContinueOk);
                    }

                    if (ruleModel.ToA != null && ruleModel.ToA > 0)
                    {
                        return await ProccessEvent2(workflow, dataObjectInut, null, ruleModel.ToA);
                    }
                }

                if (!string.IsNullOrWhiteSpace(ruleModel.ReturnError))
                {
                    return (false, ruleModel.ReturnError);
                }

                if (ruleModel.ContinueFalse != null)
                {
                    return await ProccessEvent2(workflow, dataObjectInut, ruleModel.ContinueFalse);
                }

                if (ruleModel.ToB != null && ruleModel.ToB > 0)
                {
                    return await ProccessEvent2(workflow, dataObjectInut, null, ruleModel.ToB);
                }

                return (false, "");
            }

            return await ProccessEvent2(workflow, dataObjectInut, rules.Rules.First().Rule, null);

            
        }

        public async Task<(bool success, string message)> ProccessEvent(string workflow, Dictionary<string, object> dataObjectInut)
        {

            var mWorkflow = await _cache.GetOrCreateAsync($"W_{workflow}", cacheEntry =>
            {
                cacheEntry.AbsoluteExpiration = DateTime.Now.AddYears(1);
                return _ruleRepository.GetParamWorkFlowAsync(workflow);
            });

            //as ParamWorkflowModel ??  await _ruleRepository.GetParamWorkFlowAsync(workflow);

            var rules = await _cache.GetOrCreateAsync($"R_{workflow}", cacheEntry =>
            {
                cacheEntry.AbsoluteExpiration = DateTime.Now.AddYears(1);
                return _ruleRepository.getByWorkFlowNameAsync(workflow);
            });

            //var rules = _cache.Get($"R_{workflow}") as RuleModel ?? await _ruleRepository.getByWorkFlowNameAsync(workflow);

            var parameters = new List<RuleParameter>();
            List<(string, Task<object>)> tasks = new();
            foreach (var apiname in rules.ApiCalls!)
            {

                var api = await _cache.GetOrCreateAsync($"A_{apiname}", cacheEntry =>
                {
                    cacheEntry.AbsoluteExpiration = DateTime.Now.AddYears(1);
                    return _apiRepository.GetByNameAsync(apiname);
                });

                //var api =  await _apiRepository.GetByNameAsync(apiname);
                api?.BindValuesParameters(dataObjectInut);
                var resultapi = _apiService.CallApiAsync(api!);
                tasks.Add((apiname, resultapi));
            }

            Task.WaitAll(tasks.Select(x => x.Item2).ToArray());

            foreach (var (apiname, task) in tasks)
                parameters.Add(new RuleParameter(apiname, await task ?? throw new Exception($"Erro ao consultar a api: {apiname}")));


            //var reSetting = new ReSettings() { CustomTypes = new Type[] { typeof(ExpressionUtils) } };

            var re = new RulesEngine.RulesEngine(new Workflow[] { rules.Expression }, _reSetting);

            var result = await re.ExecuteAllRulesAsync(rules.Expression.WorkflowName, parameters.ToArray());
            Console.WriteLine(result);
            //string? success = null;
            string message = string.Empty;
            bool success = true;
            result.OnSuccess((x) =>
            {
                message = x;
            });


            result.OnFail(() =>
            {
                foreach (var a in result)
                {
                    message += a.Rule.ErrorMessage + "\r\n";
                }
                success = false;
            });

            return (success, message);
        }

        //public async Task ProcessEventAsync(EventData eventData)
        //{
        //    var rules = await _ruleRepository.GetAllAsync();

        //    foreach (var rule in rules)
        //    {
        //        //var ruleContext = new RuleContext
        //        //{
        //        //    EventData = eventData,
        //        //    ApiResults = new Dictionary<string, Dictionary<string, object>>()
        //        //};

        //        //foreach (var ruleItem in rule.Rules)
        //        //{   
        //        //    if (ruleItem.ApiCalls != null && ruleItem.ApiCalls.Any())
        //        //    {
        //        //        foreach (var apiCall in ruleItem.ApiCalls)
        //        //        {
        //        //            var apiDefinition = await _apiRepository.GetByNameAsync(apiCall.ApiName);
        //        //            var parameters = PrepareParameters(apiCall.Parameters, eventData);
        //        //            var apiResult = await CallApiAsync(apiDefinition, parameters);

        //        //            ruleContext.ApiResults[apiCall.ApiName] = apiResult;
        //        //        }
        //        //    }

        //        //    var result = await _rulesEngine.ExecuteAsync(ruleItem.Expression, ruleContext);
        //        //    if (result.IsSuccess)
        //        //    {
        //        //        // Process successful rule results
        //        //    }
        //        //}
        //    }
        //}

        //private async Task<Dictionary<string, object>?> CallApiAsync(ApiDefinition apiDefinition, Dictionary<string, object> parameters)
        //{
        //    var client = new HttpClient();
        //    var requestUri = BuildRequestUri(apiDefinition.Endpoint, parameters);
        //    var response = await client.GetAsync(requestUri);
        //    response.EnsureSuccessStatusCode();

        //    var content = await response.Content.ReadAsStringAsync();
        //    return JsonSerializer.Deserialize<Dictionary<string, object>>(content);
        //}

        //private string BuildRequestUri(string endpoint, Dictionary<string, object> parameters)
        //{
        //    var query = string.Join("&", parameters.Select(p => $"{p.Key}={p.Value}"));
        //    return $"{endpoint}?{query}";
        //}

        //private Dictionary<string, object> PrepareParameters(Dictionary<string, string> apiParameters, EventData eventData)
        //{
        //    var parameters = new Dictionary<string, object>();
        //    foreach (var param in apiParameters)
        //    {
        //        var paramValue = eventData.GetType().GetProperty(param.Value)?.GetValue(eventData);
        //        parameters[param.Key] = paramValue;
        //    }
        //    return parameters;
        //}
    }


}
