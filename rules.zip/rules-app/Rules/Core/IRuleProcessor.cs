﻿using Rules.Infra.Models;

namespace Rules.Core
{
    public interface IRuleProcessor
    {
        Task<(bool success, string message)> ProccessEvent(string workflow, Dictionary<string, object> dataObjectInut);
        Task<(bool success, string message)> ProccessEvent2(string workflow, Dictionary<string, object> dataObjectInut, RuleModel4? ruleModel, int? targetRule = 0);
    }
}